module.exports=[21449,(a,b,c)=>{}];

//# sourceMappingURL=frontend__next-internal_server_app_privacy-policy_page_actions_0wo29pz.js.map