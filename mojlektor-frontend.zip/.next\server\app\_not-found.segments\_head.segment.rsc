1:"$Sreact.fragment"
2:I[64381,["/_next/static/chunks/17y_~ihvc4r-w.js","/_next/static/chunks/0y_26oe75awbj.js"],"ViewportBoundary"]
3:I[64381,["/_next/static/chunks/17y_~ihvc4r-w.js","/_next/static/chunks/0y_26oe75awbj.js"],"MetadataBoundary"]
4:"$Sreact.suspense"
5:I[12843,["/_next/static/chunks/17y_~ihvc4r-w.js","/_next/static/chunks/0y_26oe75awbj.js"],"IconMark"]
0:{"rsc":["$","$1","h",{"children":[["$","meta",null,{"name":"robots","content":"noindex"}],["$","$L2",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$L3",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"MojLektor"}],["$","meta","1",{"name":"description","content":"AI lektura i korektura za balkanske jezike."}],["$","link","2",{"rel":"icon","href":"/mojlektor_logo_white_bg.jpg"}],["$","$L5","3",{}]]}]}]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"v2KDBr1xbTblHKGiNKTJ3"}
