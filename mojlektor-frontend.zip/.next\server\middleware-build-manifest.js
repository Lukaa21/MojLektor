globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/v2KDBr1xbTblHKGiNKTJ3/_buildManifest.js",
    "static/v2KDBr1xbTblHKGiNKTJ3/_ssgManifest.js",
    "static/v2KDBr1xbTblHKGiNKTJ3/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0t~si.kra3_5q.js",
    "static/chunks/17vjdk0jajkb0.js",
    "static/chunks/0nxjca0q44tl5.js",
    "static/chunks/16.h.hb~e3~p9.js",
    "static/chunks/turbopack-07-br_2m7t4_9.js"
  ]
};
