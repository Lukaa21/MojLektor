module.exports=[57583,(a,b,c)=>{}];

//# sourceMappingURL=frontend__next-internal_server_app_buy-tokens_page_actions_13a~fd-.js.map