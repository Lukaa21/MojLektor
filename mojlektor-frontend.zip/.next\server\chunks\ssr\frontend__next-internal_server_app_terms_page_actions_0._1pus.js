module.exports=[53771,(a,b,c)=>{}];

//# sourceMappingURL=frontend__next-internal_server_app_terms_page_actions_0._1pus.js.map