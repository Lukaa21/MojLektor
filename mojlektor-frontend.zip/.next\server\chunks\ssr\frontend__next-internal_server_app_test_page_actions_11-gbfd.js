module.exports=[35892,(a,b,c)=>{}];

//# sourceMappingURL=frontend__next-internal_server_app_test_page_actions_11-gbfd.js.map