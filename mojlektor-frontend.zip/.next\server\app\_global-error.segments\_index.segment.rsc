1:"$Sreact.fragment"
2:I[32035,["/_next/static/chunks/08yb0vyff6txf.js","/_next/static/chunks/0y_26oe75awbj.js"],"default"]
3:I[91168,["/_next/static/chunks/08yb0vyff6txf.js","/_next/static/chunks/0y_26oe75awbj.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"v2KDBr1xbTblHKGiNKTJ3"}
