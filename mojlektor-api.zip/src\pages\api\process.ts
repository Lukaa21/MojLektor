import type { NextApiRequest, NextApiResponse } from "next";
import { handleCors } from "../../utils/cors";
import { requireNextAuthUser } from "../../auth/guards";
import { processText } from "../../ai/processText";
import { createFullDiff } from "../../core/diff";
import { JobStatus, Language, ServiceType } from "../../core/models";
import {
  consumeTokensForProcessing,
  refundTokensAfterFailedProcessing,
} from "../../tokens/service";
import { processRateLimit } from "../../middleware/rateLimit";
import { validateProcessInput } from "../../validation/processInput";
import { calculateTokenCost } from "../../core/tokenCost";

const MAX_INPUT_CHARS = 100_000;

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  if (handleCors(req, res)) return;
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  if (!(await processRateLimit(req, res))) return;

  const { rawText, serviceType, textType, language } = req.body as {
    rawText?: string;
    serviceType?: ServiceType;
    textType?: string;
    language?: Language;
  };

  if (!rawText || !serviceType || !textType || !language) {
    return res.status(400).json({
      error: "rawText, serviceType, textType, and language are required",
    });
  }

  if (rawText.length > MAX_INPUT_CHARS) {
    return res.status(400).json({
      error: `Input too large. Maximum ${MAX_INPUT_CHARS} characters allowed.`,
    });
  }

  const validation = validateProcessInput(serviceType, language, textType);
  if (!validation.ok) {
    return res.status(400).json({ error: validation.error });
  }

  const user = await requireNextAuthUser(req, res);
  if (!user) {
    return;
  }

  const tokenCost = calculateTokenCost(rawText.length, serviceType);
  const tokenCheck = await consumeTokensForProcessing(
    user.id,
    tokenCost,
    "/api/process"
  );

  if (!tokenCheck.ok) {
    return res.status(402).json({
      error: {
        code: "INSUFFICIENT_TOKENS",
        message: "Nedovoljno tokena za obradu teksta.",
      },
      requiredTokens: tokenCheck.requiredTokens,
      currentBalance: tokenCheck.currentBalance,
      shortfall: tokenCheck.shortfall,
      suggestedPackage: tokenCheck.suggestedPackage,
      nextLowerPackage: tokenCheck.nextLowerPackage,
      differenceToLowerPackage: tokenCheck.differenceToLowerPackage,
      redirectPath: "/buy-tokens",
    });
  }

  let processedText: string;
  let cardCount: number;
  try {
    const result = await processText(
      rawText,
      serviceType,
      textType,
      language
    );
    processedText = result.edited;
    cardCount = result.cardCount;
  } catch (err) {
    const refunded = await refundTokensAfterFailedProcessing(
      user.id,
      tokenCost,
      "/api/process"
    );
    if (!refunded) {
      return res.status(500).json({
        success: false,
        error: {
          code: "REFUND_FAILED",
          message: "AI obrada nije uspjela, a refund tokena trenutno nije moguc. Pokusajte ponovo uskoro.",
        },
      });
    }
    return res.status(500).json({
      success: false,
      error: {
        code: "LLM_ERROR",
        message: "Doslo je do greske prilikom AI obrade.",
      },
    });
  }

  const fullDiff = createFullDiff(rawText, processedText);

  return res.json({
    success: true,
    original: fullDiff.original,
    edited: fullDiff.edited,
    diff: fullDiff.diff,
    changes: fullDiff.changes,
    tokens: fullDiff.tokens,
    cardCount,
    remainingBalance: tokenCheck.remainingBalance,
    status: JobStatus.DONE,
  });
}
